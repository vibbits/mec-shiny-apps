Package: lambda.r
Type: Package
Title: Modeling Data with Functional Programming
Version: 1.1.9
Date: 2016-07-10
Depends: R (>= 3.0.0)
Suggests: RUnit
Author: Brian Lee Yung Rowe
Maintainer: Brian Lee Yung Rowe <r@zatonovo.com>
Description: A language extension to efficiently write functional programs in R. Syntax extensions include multi-part function definitions, pattern matching, guard statements, built-in (optional) type safety.
License: LGPL-3
LazyLoad: yes
NeedsCompilation: no
Packaged: 2016-07-10 13:33:55 UTC; brian
Repository: CRAN
Date/Publication: 2016-07-10 16:30:57
Built: R 3.3.0; ; 2016-07-11 10:42:41 UTC; unix
